# Samsung Data Science Project

This academic project applies Python and Power BI to support business decision-making.

## Workflow

Raw CSV Data  
→ Python / Pandas Data Cleaning  
→ Exploratory Analysis with Matplotlib  
→ Cleaned CSV Files  
→ Power BI  
→ Interactive Dashboard

## Python Libraries

- pandas
- matplotlib

## Main Analysis

- Sales analysis
- Inventory validation
- Forecast accuracy
- Production difference
- Production efficiency

## Power BI Dashboard

The Power BI report contains four pages:

1. Overview
2. Sales
3. Inventory
4. Production

## Important Note

The dataset is simulated for academic purposes and does not represent official Samsung internal data.

## How to Run

1. Put the source CSV files in the `data` folder:
   - sales.csv
   - inventory.csv
   - production.csv
   - suppliers.csv

2. Install dependencies:

   pip install -r requirements.txt

3. Run:

   python samsung_data_pipeline.py

4. The cleaned CSV files and chart outputs will be generated for use in Power BI.

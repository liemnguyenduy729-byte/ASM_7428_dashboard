import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# 1. PYTHON ENVIRONMENT
DATA = Path("data")
OUTPUT = Path("processed_data")
OUTPUT.mkdir(exist_ok=True)

# 2. IMPORT AND INSPECT THE DATA
sales = pd.read_csv(DATA / "sales.csv")
inventory = pd.read_csv(DATA / "inventory.csv")
production = pd.read_csv(DATA / "production.csv")
suppliers = pd.read_csv(DATA / "suppliers.csv")

for name, df in {
    "Sales": sales,
    "Inventory": inventory,
    "Production": production,
    "Suppliers": suppliers
}.items():
    print(f"\n--- {name} ---")
    print("Shape:", df.shape)
    print("Duplicates:", df.duplicated().sum())
    print("Missing values:")
    print(df.isna().sum())

# 3. CLEAN AND STANDARDISE THE DATA
def clean_columns(df):
    df = df.copy()
    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
        .str.replace(" ", "_", regex=False)
        .str.replace("-", "_", regex=False)
    )
    return df.drop_duplicates()

sales = clean_columns(sales)
inventory = clean_columns(inventory)
production = clean_columns(production)
suppliers = clean_columns(suppliers)

for df in [sales, inventory, production, suppliers]:
    for col in df.select_dtypes(include="object").columns:
        df[col] = (
            df[col]
            .astype("string")
            .str.strip()
            .str.replace(r"\s+", " ", regex=True)
        )

if "date" in sales.columns:
    sales["date"] = pd.to_datetime(sales["date"], errors="coerce")
    sales["month_number"] = sales["date"].dt.month
    sales["month_name"] = sales["date"].dt.month_name()

# 4. VALIDATE INVENTORY DATA
stock_columns = ["in_stock", "reorder", "out_of_stock"]

for col in stock_columns:
    if col in inventory.columns:
        inventory[col] = pd.to_numeric(inventory[col], errors="coerce")
        inventory[col] = inventory[col].fillna(0).clip(lower=0)

existing_stock_columns = [col for col in stock_columns if col in inventory.columns]

if existing_stock_columns:
    print("\n--- Inventory validation ---")
    print(inventory[existing_stock_columns].describe())

# 5. CREATE ANALYTICAL FIELDS
if {"actual_qty", "planned_qty"}.issubset(production.columns):
    production["actual_qty"] = pd.to_numeric(production["actual_qty"], errors="coerce")
    production["planned_qty"] = pd.to_numeric(production["planned_qty"], errors="coerce")
    production["production_difference"] = (
        production["actual_qty"] - production["planned_qty"]
    )
    production["production_efficiency"] = (
        production["actual_qty"]
        / production["planned_qty"].replace(0, pd.NA)
    ).fillna(0)

if {"actual_qty", "forecast_qty"}.issubset(sales.columns):
    sales["actual_qty"] = pd.to_numeric(sales["actual_qty"], errors="coerce")
    sales["forecast_qty"] = pd.to_numeric(sales["forecast_qty"], errors="coerce")
    denominator = sales["actual_qty"].abs().replace(0, pd.NA)
    sales["forecast_accuracy"] = (
        1 - (sales["actual_qty"] - sales["forecast_qty"]).abs() / denominator
    ).clip(0, 1).fillna(0)

# 6. EXPLORATORY ANALYSIS WITH PYTHON
if {"category", "sales"}.issubset(sales.columns):
    sales["sales"] = pd.to_numeric(sales["sales"], errors="coerce")
    sales_by_category = (
        sales.groupby("category", as_index=False)["sales"]
        .sum()
        .sort_values("sales", ascending=False)
    )

    print("\n--- Sales by Category ---")
    print(sales_by_category)

    sales_by_category.set_index("category")["sales"].plot(
        kind="bar",
        figsize=(10, 6)
    )
    plt.title("Total Sales by Category")
    plt.xlabel("Category")
    plt.ylabel("Total Sales")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(OUTPUT / "sales_by_category.png", dpi=200)
    plt.close()

if {"month_number", "planned_qty", "actual_qty"}.issubset(production.columns):
    monthly_production = (
        production.groupby(
            "month_number",
            as_index=False
        )[["planned_qty", "actual_qty"]]
        .sum()
        .sort_values("month_number")
    )

    monthly_production.plot(
        x="month_number",
        y=["planned_qty", "actual_qty"],
        kind="bar",
        figsize=(11, 6)
    )
    plt.title("Planned vs Actual Production")
    plt.xlabel("Month")
    plt.ylabel("Production Quantity")
    plt.tight_layout()
    plt.savefig(OUTPUT / "planned_vs_actual.png", dpi=200)
    plt.close()

# 7. EXPORT CLEANED DATA TO POWER BI
sales.to_csv(OUTPUT / "sales_cleaned.csv", index=False)
inventory.to_csv(OUTPUT / "inventory_cleaned.csv", index=False)
production.to_csv(OUTPUT / "production_cleaned.csv", index=False)
suppliers.to_csv(OUTPUT / "suppliers_cleaned.csv", index=False)

print("\nCleaned files exported successfully.")
